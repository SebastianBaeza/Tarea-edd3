Este es un caso de prueba simple para probar la Tarea 3, a continuacion estan los datos que contiene
cada archivo binario:

productos.dat
1:Pan->100
2:Azucar->400
3:Sal->300

ofertas.dat
Codigo 2 - 3 unidades
300 descuento
Productos equivalentes = {3,-1,-1,-1,-1,-1,-1,-1,-1,-1}
Codigo 3 - 3 unidades
300 descuento
Productos equivalentes = {2,-1,-1,-1,-1,-1,-1,-1,-1,-1}